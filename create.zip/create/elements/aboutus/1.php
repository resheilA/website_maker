<!---------------------------------- ABOUT US SECTION -------------------------------------------->
   
   
   <section class="about-us py-5 " id="about-us">
    <div class="container mt-5">
	<div class="row">
		<div class="col-md-8">
		    <h1 class='text-success'>Welcome!</h1>
		    <h2>Know More About Us</h2>
		    <hr>
		    <p><?php echo $content_business[0]["about_us"]; ?></p>
		    <button type="button" class="btn btn-success">Let's Know More</button>

		</div>
		<div class="col-md-4">
		    <img style="width:100%;" src="" alt="">
		</div>
	</div>
</div>
</section>


<!---------------------------------- END -------------------------------------------->